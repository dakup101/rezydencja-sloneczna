<?php get_header(); ?>
<main class="page-main">
    <h1 class="text-center mt-5 mb-5">404</h1>
    <h3 class="text-center mb-5">Nie znaleziono strony</h3>
</main>
<?php get_footer(); ?>