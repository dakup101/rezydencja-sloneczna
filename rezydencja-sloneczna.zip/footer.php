<?php if (!is_single()) : ?>

<?php get_template_part('/components/component-contact-form'); ?>

<?php endif; ?>

<?php
get_template_part('/components/component-footer');
?>
</body>

</html>