<?php
get_template_part('/components/component-footer');
?>
</body>
</html>
