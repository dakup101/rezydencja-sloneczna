export default {
    is_prod: false
}